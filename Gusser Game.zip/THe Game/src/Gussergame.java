
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

public class Gussergame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JLabel DisplayWinnerTF;
	private JPanel panel_2;

	private JPanel contentPane;
	private JTextField userinput;
	private JTextField userScoreTF;
	private JTextField computerChoiceTF;
	private JTextField computerScoreTF;
	private JTextField RoundTF;
	private JTextField targetTF;

	int computerscore = 1;
	int userscore = 1;
	int round = 2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					Gussergame frame = new Gussergame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Gussergame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setSize(900, 850);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 128, 128));
		panel.setBounds(42, 137, 351, 443);
		contentPane.add(panel);
		panel.setLayout(null);

		computerChoiceTF = new JTextField();
		computerChoiceTF.setFont(new Font("Tahoma", Font.PLAIN, 25));
		computerChoiceTF.setHorizontalAlignment(SwingConstants.CENTER);
		computerChoiceTF.setEditable(false);
		computerChoiceTF.setBounds(117, 229, 114, 122);
		panel.add(computerChoiceTF);
		computerChoiceTF.setColumns(10);

		JLabel lblNewLabel = new JLabel("Score");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(27, 153, 80, 26);
		panel.add(lblNewLabel);

		computerScoreTF = new JTextField();
		computerScoreTF.setFont(new Font("Tahoma", Font.PLAIN, 22));
		computerScoreTF.setHorizontalAlignment(SwingConstants.CENTER);
		computerScoreTF.setBounds(117, 148, 114, 36);
		panel.add(computerScoreTF);
		computerScoreTF.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("Computer");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 24));
		lblNewLabel_1.setBounds(117, 32, 143, 56);
		panel.add(lblNewLabel_1);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(47, 79, 79));
		panel_1.setBounds(476, 137, 351, 443);
		contentPane.add(panel_1);
		panel_1.setLayout(null);

		userinput = new JTextField();
		userinput.setFont(new Font("Tahoma", Font.PLAIN, 25));
		userinput.setHorizontalAlignment(SwingConstants.CENTER);
		userinput.setBounds(110, 222, 112, 123);
		panel_1.add(userinput);
		userinput.setColumns(10);

		JLabel UserInput = new JLabel("Score");
		UserInput.setHorizontalAlignment(SwingConstants.CENTER);
		UserInput.setFont(new Font("Tahoma", Font.PLAIN, 22));
		UserInput.setBounds(37, 162, 79, 27);
		panel_1.add(UserInput);

		userScoreTF = new JTextField();
		userScoreTF.setFont(new Font("Tahoma", Font.PLAIN, 22));
		userScoreTF.setHorizontalAlignment(SwingConstants.CENTER);
		userScoreTF.setBounds(110, 162, 112, 37);
		panel_1.add(userScoreTF);
		userScoreTF.setColumns(10);

		JButton Guessbutton = new JButton("Guess");
		Guessbutton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				int computerChoice = (int) Math.floor(Math.random() * 10);
				int targetnumber = (int) Math.floor(Math.random() * 10);
				int input = Integer.valueOf(userinput.getText()).intValue();
				int compD = Math.abs(computerChoice - targetnumber);
				int userD = Math.abs(input - targetnumber);
				if (input >= 0 && input <= 9) {

					if (userD < compD) {
						DisplayWinnerTF.setText("You Won");
						panel_2.setBackground(Color.BLUE);
						computerChoiceTF.setText(new DecimalFormat("0").format(computerChoice));
						userScoreTF.setText(new DecimalFormat("0").format(userscore++));
						targetTF.setText(new DecimalFormat("0").format(targetnumber));

					} else if (compD < userD) {
						DisplayWinnerTF.setText("Computer Won");
						panel_2.setBackground(Color.green);
						computerChoiceTF.setText(new DecimalFormat("0").format(computerChoice));
						computerScoreTF.setText(new DecimalFormat("0").format(computerChoice++));
						targetTF.setText(new DecimalFormat("0").format(targetnumber));
					} else if (compD == userD) {
						DisplayWinnerTF.setText("It's a Tie");
						panel_2.setBackground(Color.BLUE);
						computerChoiceTF.setText(new DecimalFormat("0").format(computerChoice));
						userScoreTF.setText(new DecimalFormat("0").format(userscore++));
						computerScoreTF.setText(new DecimalFormat("0").format(computerChoice++));

						targetTF.setText(new DecimalFormat("0").format(targetnumber));
					}
				} else {
					Toolkit.getDefaultToolkit().beep();
					JOptionPane.showConfirmDialog(null, "Enter a number between 0& 9", "Error Message",
							JOptionPane.ERROR_MESSAGE);
					userinput.setText("");
				}
			}
		});
		Guessbutton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		Guessbutton.setBounds(110, 391, 89, 23);
		panel_1.add(Guessbutton);

		JLabel lblNewLabel_2 = new JLabel("You");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 24));
		lblNewLabel_2.setBounds(134, 55, 125, 55);
		panel_1.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("Round");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(318, 61, 49, 14);
		contentPane.add(lblNewLabel_3);

		RoundTF = new JTextField();
		RoundTF.setFont(new Font("Tahoma", Font.PLAIN, 24));
		RoundTF.setHorizontalAlignment(SwingConstants.CENTER);
		RoundTF.setEditable(false);
		RoundTF.setBounds(411, 45, 96, 35);
		contentPane.add(RoundTF);
		RoundTF.setText("1");

		JLabel lblNewLabel_4 = new JLabel("Target");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(318, 99, 49, 14);
		contentPane.add(lblNewLabel_4);

		targetTF = new JTextField();
		targetTF.setFont(new Font("Tahoma", Font.PLAIN, 22));
		targetTF.setHorizontalAlignment(SwingConstants.CENTER);
		targetTF.setBounds(411, 96, 96, 30);
		contentPane.add(targetTF);
		targetTF.setColumns(10);

		JButton NextRoundTF = new JButton("Next Round");
		NextRoundTF.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				computerChoiceTF.setText("");
				userinput.setText("");
				targetTF.setText("");
				DisplayWinnerTF.setText("Waiting !!");
				RoundTF.setText(new DecimalFormat("0").format(round++));
				panel_2.setBackground(Color.white);
			}
		});
		NextRoundTF.setFont(new Font("Tahoma", Font.PLAIN, 17));
		NextRoundTF.setBackground(UIManager.getColor("Button.background"));
		NextRoundTF.setBounds(318, 745, 200, 35);
		contentPane.add(NextRoundTF);

		panel_2 = new JPanel();
		panel_2.setBounds(303, 604, 300, 100);
		contentPane.add(panel_2);
		panel_2.setLayout(null);

		DisplayWinnerTF = new JLabel("Waiting !!");
		DisplayWinnerTF.setFont(new Font("Tahoma", Font.PLAIN, 32));
		DisplayWinnerTF.setHorizontalAlignment(SwingConstants.CENTER);
		DisplayWinnerTF.setBounds(10, 11, 270, 80);
		panel_2.add(DisplayWinnerTF);
	}

	protected Object valueof(String text) {
		// TODO Auto-generated method stub
		return null;
	}
}
